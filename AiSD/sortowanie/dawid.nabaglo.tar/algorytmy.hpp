void insert_sort(int *tab, int n);
void bubble_sort(int *tab, int n);