/*
 Podanie liczby np. n = 20
 wczytanie n (20) elementow z pliku
 format pliku z danymi (oddzielone spacjami):
 1 2 3 4 5

 dynamiczne alokowanie pamięci
 Wyświetlenie menu
 1- insert
 2-6 - metody sortowania
 7 - exit

 wypisanie wyników
 plik z danymi nazywa się "dane" (nie "dane.txt")


narysować dane
 ^ czas [s]
 |
 |
 |       /---
 |   /---
 |  /
 --------------> rozmiar problem [n]

 mierzenie czasu
 1) gettimeofday
 2) algorytm
 3) jeszcze raz gettimeofday
 4) obliczenie różnicy

 */

int main() {
    return 0;
}